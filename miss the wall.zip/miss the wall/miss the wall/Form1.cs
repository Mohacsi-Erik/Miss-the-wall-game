﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace miss_the_wall
{
    public partial class Form1 : Form
    {
        public Random r = new Random();
        public int time = 0;
        public int speed = 0;
        public Form1()
        {
            Modell k = new Modell();
            Persistance f = new Persistance();
            InitializeComponent();
            Bitmap pla = new Bitmap("player.jpg");
            Bitmap obj = new Bitmap("rock.jpg");
            PictureBox player = new PictureBox();
            player.Size = new Size(50, 50);
            player.Location = new Point(225, 425);
            player.Image = pla;
            player.SizeMode = PictureBoxSizeMode.StretchImage;
            this.Controls.Add(player);
            label2.Text = "Maxrecord: " + f.Import();
            Timer b = new Timer();
            b.Interval = 16;
            List<PictureBox> objects = new List<PictureBox>();
            KeyDown += (s, e) =>
              {
                  this.Controls.Remove(label1);
                  b.Start();
                  if (e.KeyCode == Keys.A)
                  {
                      speed = -10;
                  }
                  if (e.KeyCode == Keys.D)
                  {
                      speed = 10;
                  }
              };
            KeyUp += (s, e) =>
              {
                  if (e.KeyCode == Keys.A && speed == -10)
                  {
                      speed = 0;
                  }
                  if (e.KeyCode == Keys.D && speed == 10)
                  {
                      speed = 0;
                  }
              };
            b.Tick += (s, e) =>
            {
                label2.Text = "Score: " + k.score;
                player.Location = new Point(player.Location.X + speed, player.Location.Y);
                if (player.Location.X + player.Width > this.Width)
                { player.Location = new Point(this.Width - player.Width - 15, player.Location.Y); }
                if (player.Location.X < 0)
                { player.Location = new Point(0, player.Location.Y); }
                time++;
                foreach (PictureBox item in objects)
                {
                    item.Location = new Point(item.Location.X, item.Location.Y + 5);
                    if (item.Bounds.IntersectsWith(player.Bounds))
                    {
                        b.Stop();
                        MessageBox.Show("Game Over");
                        f.Export(k.score);
                        Application.Restart();
                    }
                }
                if (time == 15)
                {
                    int szam1 = r.Next(0, 575);
                    int szam2 = r.Next(0, 575);
                    PictureBox object1 = new PictureBox();
                    objects.Add(object1);
                    objects[objects.Count() - 1].Size = new Size(25, 25);
                    objects[objects.Count() - 1].Location = new Point(szam1, 0);
                    objects[objects.Count() - 1].Image = obj;
                    objects[objects.Count() - 1].SizeMode = PictureBoxSizeMode.StretchImage;
                    this.Controls.Add(objects[objects.Count() - 1]);
                    PictureBox object2 = new PictureBox();
                    this.Controls.Add(object2);
                    objects[objects.Count() - 1].Size = new Size(25, 25);
                    objects[objects.Count() - 1].Location = new Point(szam2, 0);
                    objects[objects.Count() - 1].Image = obj;
                    objects[objects.Count() - 1].SizeMode = PictureBoxSizeMode.StretchImage;
                    objects.Add(object2);
                    time = 0;
                }
                for (int i=0 ;i<objects.Count() ;i++)
                {
                    if(objects[i].Location.Y>this.Height*1.2)
                    {
                        objects.Remove(objects[i]);
                        k.score++;                      
                    }
                }
            };
        }
    }
}
